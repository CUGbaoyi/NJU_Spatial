# %% [markdown]
# # 空间自相关分析：美国民主党选票与LGBT人口分布
#
# 本代码研究以下核心问题：
# 1. 美国各州民主党投票率是否存在显著的空间自相关？
# 2. 美国各州LGBT人口比例是否存在显著的空间自相关？
# 3. 民主党投票率与LGBT人口比例之间是否存在空间交叉相关？
#    （即：民主党选票高的州，其邻近州的LGBT比例是否也高？）
#
# 分析流程：
# 1. 探索性数据分析（EDA）
# 2. 权重矩阵的构建与选择
# 3. 权重矩阵的可视化诊断
# 4. Global Moran's I 全局空间自相关检验（含双变量）
# 5. LISA 局部空间自相关分析
# 6. Getis-Ord Gi* 热点分析
# 7. 稳健性检验（多权重对比）

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.patches import Patch
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# 空间分析核心库
import geopandas as gpd
from libpysal.weights import Queen, KNN
from esda.moran import Moran, Moran_Local, Moran_BV, Moran_Local_BV
from esda.getisord import G_Local

# 显示设置
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Noto Sans SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 100

print("=" * 65)
print("空间自相关分析：美国民主党选票与LGBT人口分布")
print("核心问题：民主党选票高的州和LGBT分布是否存在空间自相关？")
print("=" * 65)

# %% ---------------------------------------------------------------
# 数据加载与合并
# ---------------------------------------------------------------
# 数据来源说明：
#   州边界 shapefile：US Census Bureau TIGER/Line 2020
#   民主党投票率：2020年总统选举（Biden %）
#   LGBT人口比例：Williams Institute 2020-2021 州级估计
#   属性数据文件：data/usa/us_states_data.csv

import os

data_dir = 'data/usa'

# --- 加载美国州边界 shapefile ---
# 优先使用已缓存的数据，否则从 Census Bureau 下载
shp_path_census = os.path.join(data_dir, 'cb_2020_us_state_20m', 'cb_2020_us_state_20m.shp')
shp_path_geojson = os.path.join(data_dir, 'us_states.geojson')

if os.path.exists(shp_path_census):
    shp_path = shp_path_census
    print("\n使用缓存的Census shapefile")
elif os.path.exists(shp_path_geojson):
    shp_path = shp_path_geojson
    print("\n使用缓存的GeoJSON备用数据")
else:
    import urllib.request
    import zipfile

    zip_url = 'https://www2.census.gov/geo/tiger/GENZ2020/shp/cb_2020_us_state_20m.zip'
    zip_path = os.path.join(data_dir, 'cb_2020_us_state_20m.zip')

    print("\n正在下载美国州边界数据...")
    try:
        urllib.request.urlretrieve(zip_url, zip_path)
        print(f"  下载完成: {zip_path}")

        os.makedirs(os.path.dirname(shp_path_census), exist_ok=True)
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(os.path.dirname(shp_path_census))
        print(f"  解压完成")

        os.remove(zip_path)
        shp_path = shp_path_census
    except Exception as e:
        print(f"  Census下载失败 ({e})，尝试备用GeoJSON...")
        geojson_url = 'https://raw.githubusercontent.com/PublicaMundi/MappingAPI/master/data/geojson/us-states.json'
        urllib.request.urlretrieve(geojson_url, shp_path_geojson)
        print(f"  GeoJSON备用方案加载完成")
        shp_path = shp_path_geojson

# 读取shapefile
gdf_raw = gpd.read_file(shp_path)
print(f"\n[1] Shapefile 加载完成")
print(f"    几何类型: {gdf_raw.geometry.type.unique()}")
print(f"    坐标系: {gdf_raw.crs}")
print(f"    空间单元数: {len(gdf_raw)}")
print(f"    列: {gdf_raw.columns.tolist()}")

# --- 加载属性数据 ---
csv_path = os.path.join(data_dir, 'us_states_data.csv')
df_attr = pd.read_csv(csv_path)
print(f"\n[2] 属性数据加载完成")
print(f"    记录数: {len(df_attr)}")
print(f"    变量: {df_attr.columns.tolist()}")
print(f"    民主党投票率范围: {df_attr['dem_pct'].min():.1f}% ~ {df_attr['dem_pct'].max():.1f}%")
print(f"    LGBT人口比例范围: {df_attr['lgbt_pct'].min():.1f}% ~ {df_attr['lgbt_pct'].max():.1f}%")

# %% ---------------------------------------------------------------
# 数据合并：CSV → Shapefile
# ---------------------------------------------------------------
# Census shapefile 的 STUSPS 字段是州缩写（如 'TX', 'CA'）
# 备用 GeoJSON 的 name 字段是全州名（如 'Texas'）
# 需要自适应匹配

if 'STUSPS' in gdf_raw.columns:
    # Census shapefile: 用州缩写匹配
    shp_state_col = 'STUSPS'
    csv_match_col = 'state'
elif 'postal' in gdf_raw.columns:
    shp_state_col = 'postal'
    csv_match_col = 'state'
elif 'name' in gdf_raw.columns:
    # 备用 GeoJSON: 用全州名匹配
    shp_state_col = 'name'
    csv_match_col = 'state_name'
else:
    shp_state_col = gdf_raw.columns[1]
    csv_match_col = 'state'

print(f"\n匹配字段: shapefile.{shp_state_col} ↔ CSV.{csv_match_col}")

# 检查匹配情况
shp_vals = set(gdf_raw[shp_state_col].str.strip())
csv_vals = set(df_attr[csv_match_col].str.strip())
matched = csv_vals & shp_vals
unmatched_csv = csv_vals - shp_vals
unmatched_shp = shp_vals - csv_vals

print(f"  匹配成功: {len(matched)}/{len(csv_vals)} 个州")
if unmatched_csv:
    print(f"  CSV中有但SHP中无: {unmatched_csv}")
if unmatched_shp:
    print(f"  SHP中有但CSV中无: {unmatched_shp} (非州实体，如PR/VI等)")

# 合并
gdf_merged = gdf_raw.merge(
    df_attr,
    left_on=shp_state_col,
    right_on=csv_match_col,
    how='inner'
)

print(f"\n[3] 数据合并完成: {len(gdf_merged)} 个空间单元")
print(f"    包含: {gdf_merged['state_name'].tolist()}")

# %% ---------------------------------------------------------------
# 选择研究变量
# ---------------------------------------------------------------
# 两个核心变量：
#   dem_pct  — 民主党投票率（2020年Biden得票%）
#   lgbt_pct — LGBT人口比例（%）

VAR_DEM = 'dem_pct'
VAR_LGBT = 'lgbt_pct'

VAR_DEM_LABEL = '民主党投票率（Biden 2020，%）'
VAR_LGBT_LABEL = 'LGBT人口比例（%）'

print(f"\n研究变量:")
print(f"  V1: {VAR_DEM_LABEL}")
print(f"  V2: {VAR_LGBT_LABEL}")

# 处理缺失值
gdf_valid = gdf_merged.dropna(subset=[VAR_DEM, VAR_LGBT]).copy()
dem_values = gdf_valid[VAR_DEM].values.astype(float)
lgbt_values = gdf_valid[VAR_LGBT].values.astype(float)
state_names = gdf_valid['state_name'].tolist()

print(f"有效观测: {len(gdf_valid)} 个州")

# %% ---------------------------------------------------------------
# 简单相关系数（非空间）
# ---------------------------------------------------------------
from scipy import stats

corr, corr_p = stats.pearsonr(dem_values, lgbt_values)
print(f"\n【民主党投票率 vs LGBT比例 相关系数（非空间）】")
print(f"  Pearson r = {corr:.4f}, p = {corr_p:.6f}")
print(f"  → 两变量在数值上{'高度' if abs(corr) > 0.7 else '中等' if abs(corr) > 0.4 else '弱'}相关")
print(f"  → 但这是非空间相关，空间自相关分析将揭示地理维度上的关系！")

# %% [markdown]
# ---
# # 步骤一：探索性数据分析（EDA）

# %% ---------------------------------------------------------------
# 1.1 基本统计特征
# ---------------------------------------------------------------
print("\n" + "=" * 65)
print("步骤一：探索性数据分析（EDA）")
print("=" * 65)

for var_name, var_label in [(VAR_DEM, VAR_DEM_LABEL), (VAR_LGBT, VAR_LGBT_LABEL)]:
    vals = gdf_valid[var_name].values.astype(float)
    print(f"\n【{var_label} 基本统计量】")
    print(f"  均值:     {np.mean(vals):.2f}")
    print(f"  中位数:   {np.median(vals):.2f}")
    print(f"  标准差:   {np.std(vals):.2f}")
    print(f"  最小值:   {np.min(vals):.2f} — {gdf_valid.loc[vals.argmin(), 'state_name']}")
    print(f"  最大值:   {np.max(vals):.2f} — {gdf_valid.loc[vals.argmax(), 'state_name']}")
    print(f"  偏度:     {stats.skew(vals):.3f}")
    print(f"  峰度:     {stats.kurtosis(vals):.3f}")

# %% ---------------------------------------------------------------
# 1.2 双变量可视化 —— 散点图 + 分布图
# ---------------------------------------------------------------
fig, axes = plt.subplots(2, 3, figsize=(20, 12))
fig.suptitle('探索性数据分析：民主党投票率 vs LGBT人口比例\n（美国各州，2020年）',
             fontsize=15, y=1.01)

# (a) 民主党投票率直方图
ax = axes[0, 0]
ax.hist(dem_values, bins=20, density=True, alpha=0.7, color='#2166ac', edgecolor='white')
kde = stats.gaussian_kde(dem_values)
x_kde = np.linspace(dem_values.min(), dem_values.max(), 200)
ax.plot(x_kde, kde(x_kde), 'darkblue', linewidth=2)
ax.axvline(np.mean(dem_values), color='red', linestyle='--', linewidth=2, label=f'均值={np.mean(dem_values):.1f}%')
ax.set_xlabel('民主党投票率 (%)', fontsize=11)
ax.set_ylabel('密度', fontsize=11)
ax.set_title('民主党投票率分布', fontsize=13)
ax.legend(fontsize=9)

# (b) LGBT比例直方图
ax = axes[0, 1]
ax.hist(lgbt_values, bins=20, density=True, alpha=0.7, color='#d6604d', edgecolor='white')
kde = stats.gaussian_kde(lgbt_values)
x_kde = np.linspace(lgbt_values.min(), lgbt_values.max(), 200)
ax.plot(x_kde, kde(x_kde), 'darkred', linewidth=2)
ax.axvline(np.mean(lgbt_values), color='blue', linestyle='--', linewidth=2, label=f'均值={np.mean(lgbt_values):.1f}%')
ax.set_xlabel('LGBT人口比例 (%)', fontsize=11)
ax.set_ylabel('密度', fontsize=11)
ax.set_title('LGBT人口比例分布', fontsize=13)
ax.legend(fontsize=9)

# (c) 散点图 + 拟合线
ax = axes[0, 2]
ax.scatter(dem_values, lgbt_values, s=80, alpha=0.7, c='#5e3c99', edgecolors='white', linewidth=0.5)
fit = np.polyfit(dem_values, lgbt_values, 1)
x_fit = np.linspace(dem_values.min(), dem_values.max(), 100)
ax.plot(x_fit, np.polyval(fit, x_fit), 'r-', linewidth=2, label=f'r = {corr:.3f}, p = {corr_p:.4f}')
# 标注极端值
for i, (d, l, s) in enumerate(zip(dem_values, lgbt_values, state_names)):
    if d > 55 or l > 5 or d < 35:
        ax.annotate(s, (d, l), fontsize=7, alpha=0.7,
                    xytext=(5, 5), textcoords='offset points')
ax.set_xlabel('民主党投票率 (%)', fontsize=11)
ax.set_ylabel('LGBT人口比例 (%)', fontsize=11)
ax.set_title('民主党投票率 vs LGBT比例', fontsize=13)
ax.legend(fontsize=9)

# (d) 民主党投票率箱线图（按区域）
ax = axes[1, 0]
region_order = ['Northeast', 'West', 'Midwest', 'South']
region_data = [gdf_valid[gdf_valid['region'] == r][VAR_DEM].values for r in region_order]
bp = ax.boxplot(region_data, labels=region_order, patch_artist=True,
                boxprops=dict(facecolor='#2166ac', alpha=0.6),
                medianprops=dict(color='white', linewidth=2))
ax.set_ylabel('民主党投票率 (%)', fontsize=11)
ax.set_title('民主党投票率：区域差异', fontsize=13)

# (e) LGBT比例箱线图（按区域）
ax = axes[1, 1]
region_data_l = [gdf_valid[gdf_valid['region'] == r][VAR_LGBT].values for r in region_order]
bp = ax.boxplot(region_data_l, labels=region_order, patch_artist=True,
                boxprops=dict(facecolor='#d6604d', alpha=0.6),
                medianprops=dict(color='white', linewidth=2))
ax.set_ylabel('LGBT人口比例 (%)', fontsize=11)
ax.set_title('LGBT人口比例：区域差异', fontsize=13)

# (f) 各州条形图对比
ax = axes[1, 2]
gdf_sorted = gdf_valid.sort_values(VAR_DEM)
x_idx = range(len(gdf_sorted))
width = 0.35
bars1 = ax.barh([i - width/2 for i in x_idx], gdf_sorted[VAR_DEM].values,
                height=width, color='#2166ac', alpha=0.7, label='民主党投票率%')
ax2 = ax.twiny()
bars2 = ax2.barh([i + width/2 for i in x_idx], gdf_sorted[VAR_LGBT].values,
                 height=width, color='#d6604d', alpha=0.7, label='LGBT比例%')
ax.set_yticks(x_idx)
ax.set_yticklabels(gdf_sorted['state_name'].values, fontsize=7)
ax.set_xlabel('民主党投票率 (%)', fontsize=10)
ax2.set_xlabel('LGBT比例 (%)', fontsize=10)
ax.set_title('各州对比（按民主党投票率排序）', fontsize=12)
lines1, labels1 = ax.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax.legend(lines1 + lines2, labels1 + labels2, loc='lower right', fontsize=8)

plt.tight_layout()
plt.savefig('output_usa_01_eda.png', dpi=150, bbox_inches='tight')
plt.show()

# %% ---------------------------------------------------------------
# 1.3 空间分布可视化 —— 用肉眼看空间模式
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(22, 8))

# (a) 民主党投票率空间分布
ax = axes[0]
gdf_valid.plot(column=VAR_DEM, cmap='Blues', legend=True, ax=ax,
               legend_kwds={'label': '民主党投票率 (%)', 'shrink': 0.7},
               edgecolors='gray', linewidths=0.5, vmin=25, vmax=95)
for idx, row in gdf_valid.iterrows():
    centroid = row.geometry.centroid
    ax.annotate(row['state'], (centroid.x, centroid.y),
                fontsize=6, ha='center', va='center', color='#333333', fontweight='bold')
ax.set_title('2020年 美国各州民主党投票率空间分布\n（EDA：肉眼观察空间聚集模式）', fontsize=13)
ax.axis('off')

# (b) LGBT人口比例空间分布
ax = axes[1]
gdf_valid.plot(column=VAR_LGBT, cmap='Reds', legend=True, ax=ax,
               legend_kwds={'label': 'LGBT人口比例 (%)', 'shrink': 0.7},
               edgecolors='gray', linewidths=0.5, vmin=1.5, vmax=10.5)
for idx, row in gdf_valid.iterrows():
    centroid = row.geometry.centroid
    ax.annotate(row['state'], (centroid.x, centroid.y),
                fontsize=6, ha='center', va='center', color='#333333', fontweight='bold')
ax.set_title('2020年 美国各州LGBT人口比例空间分布\n（EDA：肉眼观察空间聚集模式）', fontsize=13)
ax.axis('off')

plt.tight_layout()
plt.savefig('output_usa_02_spatial_distribution.png', dpi=150, bbox_inches='tight')
plt.show()

print("\n【EDA直觉判断】")
print("  请观察空间分布图，回答以下问题：")
print("  1. 东北部和西海岸的民主党投票率是否明显高于南方和中西部？")
print("  2. LGBT人口比例是否呈现出类似的'海岸高、内陆低'的空间格局？")
print("  3. 南部 Bible Belt 地区的两个变量是否同时偏低？")
print("  4. 两个变量的空间分布模式看起来有多相似？")
print("  → 如果两变量的空间模式相似，可能存在空间交叉相关！")

# %% [markdown]
# ---
# # 步骤二：权重矩阵的构建与选择

# %% ---------------------------------------------------------------
# 2.1 构建三种权重方案
# ---------------------------------------------------------------
print("\n" + "=" * 65)
print("步骤二：权重矩阵的构建与选择")
print("=" * 65)

# --- Queen 邻接矩阵 ---
queen_ok = False
try:
    w_queen = Queen.from_dataframe(gdf_valid)
    w_queen.transform = 'r'
    queen_ok = True
    islands = w_queen.islands if hasattr(w_queen, 'islands') else []
    n_islands = len(islands)
    avg_neighbors = np.mean([len(v) for v in w_queen.neighbors.values()])
    print(f"\n  [1] Queen 邻接矩阵: 构建成功")
    print(f"      空间单元数: {w_queen.n}")
    print(f"      平均邻居数: {avg_neighbors:.1f}")
    print(f"      孤岛数（无邻居）: {n_islands}")
    if n_islands > 0:
        iso_names = [gdf_valid.iloc[i]['state_name'] for i in islands]
        print(f"      孤岛州: {iso_names}")
        print(f"      (注: AK/HI 不与其他州接壤，Queen权重下为孤岛)")
except Exception as e:
    print(f"\n  [1] Queen 邻接矩阵: 构建失败 ({e})")

# --- KNN(4) ---
w_knn4 = KNN.from_dataframe(gdf_valid, k=4)
w_knn4.transform = 'r'
print(f"\n  [2] KNN(4) 矩阵: 构建成功（每个州4个最近邻居）")

# --- KNN(8) ---
w_knn8 = KNN.from_dataframe(gdf_valid, k=8)
w_knn8.transform = 'r'
print(f"\n  [3] KNN(8) 矩阵: 构建成功（每个州8个最近邻居）")

weight_schemes = {}
if queen_ok:
    weight_schemes['Queen邻接'] = w_queen
weight_schemes['KNN(4)'] = w_knn4
weight_schemes['KNN(8)'] = w_knn8

# %% ---------------------------------------------------------------
# 2.2 权重矩阵可视化
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(22, 6))
fig.suptitle('权重矩阵质量检查：三种方案对比', fontsize=14, y=1.02)

w_demo_name = 'Queen邻接' if queen_ok else 'KNN(4)'
w_demo = weight_schemes[w_demo_name]

# (1) 连接图
ax = axes[0]
gdf_valid.plot(ax=ax, facecolor='lightyellow', edgecolor='gray', linewidths=0.5)
centroids = gdf_valid.geometry.centroid
coord_list = list(zip(centroids.x, centroids.y))
coord_map = dict(zip(range(len(coord_list)), coord_list))

for i, neighbors in w_demo.neighbors.items():
    ci = coord_map.get(i)
    if ci is None:
        continue
    for j in neighbors:
        cj = coord_map.get(j)
        if cj is None:
            continue
        ax.plot([ci[0], cj[0]], [ci[1], cj[1]], 'b-', alpha=0.15, linewidth=0.4)
ax.set_title(f'连接图（{w_demo_name}）\n蓝线=邻居关系', fontsize=12)
ax.axis('off')

# (2) 权重分布
ax = axes[1]
all_weights = []
for i in w_demo.id_order:
    all_weights.extend(w_demo.weights[i])
ax.hist(all_weights, bins=25, color='steelblue', edgecolor='white', alpha=0.8)
ax.set_xlabel('权重值（行标准化后）', fontsize=11)
ax.set_ylabel('频数', fontsize=11)
ax.set_title(f'权重分布（{w_demo_name}）', fontsize=12)

# (3) 邻居数量分布对比（箱线图 + 散点）
ax = axes[2]
schemes_names = list(weight_schemes.keys())
n_neighbors_data = []
for name, w in weight_schemes.items():
    n_neighbors_data.append([len(w.neighbors[i]) for i in w.id_order])

# 画箱线图
bp = ax.boxplot(n_neighbors_data, labels=schemes_names, patch_artist=True,
                boxprops=dict(facecolor='steelblue', alpha=0.4),
                medianprops=dict(color='red', linewidth=2),
                whiskerprops=dict(color='gray', linewidth=1),
                capprops=dict(color='gray', linewidth=1),
                widths=0.4)

# 叠加 jitter 散点 —— 使得 KNN（邻居数完全一致）也能看到数据
for i, nn_list in enumerate(n_neighbors_data):
    unique_vals = sorted(set(nn_list))
    for v in unique_vals:
        count = nn_list.count(v)
        jitter = np.random.normal(0, 0.06, count)
        ax.scatter([i] * count + jitter, [v] * count,
                   s=20, alpha=0.35, c='#d62728', edgecolors='none', zorder=3)

# 在每个箱线图上方标注均值和范围
for i, nn_list in enumerate(n_neighbors_data):
    mn, mx = min(nn_list), max(nn_list)
    avg = np.mean(nn_list)
    label = f'均值={avg:.1f}' if mn == mx else f'均值={avg:.1f}\n范围=[{mn},{mx}]'
    ax.text(i, mx + 0.3, label, ha='center', fontsize=9,
            bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.7))

ax.set_ylabel('邻居数量', fontsize=11)
ax.set_title('邻居数量分布对比（箱线图 + 散点）', fontsize=12)

plt.tight_layout()
plt.savefig('output_usa_03_weight_diagnostics.png', dpi=150, bbox_inches='tight')
plt.show()

print("\n【权重矩阵诊断结论】")
if queen_ok:
    print(f"  Queen方案: 邻居数因地理面积差异大，AK/HI为孤岛")
    print(f"  → 这可能导致阿拉斯加和夏威夷在Queen分析中被排除")
    print(f"  → 使用KNN作为稳健性检验是必要的！")
print(f"  KNN方案: 所有州保证固定邻居数，包含AK/HI")

# %% [markdown]
# ---
# # 步骤三：Global Moran's I 全局空间自相关检验

# %% ---------------------------------------------------------------
# 3.1 单变量 Global Moran's I — 民主党投票率
# ---------------------------------------------------------------
print("\n" + "=" * 65)
print("步骤三：Global Moran's I 全局空间自相关检验")
print("=" * 65)

moran_dem_results = {}
moran_lgbt_results = {}

for var_name, var_label, results_dict in [
    (VAR_DEM, VAR_DEM_LABEL, moran_dem_results),
    (VAR_LGBT, VAR_LGBT_LABEL, moran_lgbt_results)
]:
    vals = gdf_valid[var_name].values.astype(float)
    print(f"\n{'─' * 60}")
    print(f"\n  >>> 变量: {var_label} <<<")

    for name, w in weight_schemes.items():
        moran = Moran(vals, w, permutations=999)
        results_dict[name] = moran

        sig = ("***" if moran.p_sim < 0.001 else
               "**" if moran.p_sim < 0.01 else
               "*" if moran.p_sim < 0.05 else "不显著")
        direction = "正空间自相关（HH/LL聚集）" if moran.I > 0 else "负空间自相关（HL/LH离散）"
        print(f"    {name:<12}: I={moran.I:7.4f}, Z={moran.z_norm:7.3f}, "
              f"p={moran.p_sim:.4f} {sig} → {direction}")

    # 识别最优结果
    best = max(results_dict.values(), key=lambda m: abs(m.z_norm))
    print(f"\n  → 结论: {var_label}")
    print(f"     Moran's I 在所有权重方案下均{'为正且高度显著' if all(m.I > 0 and m.p_sim < 0.05 for m in results_dict.values()) else '方向不一致'}")
    print(f"     表明美国各州{var_label}存在{'显著' if best.p_sim < 0.05 else '不显著的'}空间聚集现象")

# %% ---------------------------------------------------------------
# 3.2 双变量 Global Moran's I — 核心研究问题！
# ---------------------------------------------------------------
# 双变量 Moran's I 检验：
#   给定州 i 的民主党投票率（高/低），
#   其邻居 j 的 LGBT 比例是否也倾向于高/低？
#   这就是空间交叉相关（spatial cross-correlation）

print(f"\n{'─' * 60}")
print(f"\n  >>> 双变量 Moran's I: 民主党投票率 vs LGBT比例（空间交叉相关）<<<")
print(f"      核心研究问题：民主党选票高的州，其邻近州的LGBT人口比例是否也高？")

moran_bv_results = {}

for name, w in weight_schemes.items():
    moran_bv = Moran_BV(dem_values, lgbt_values, w, permutations=999)
    moran_bv_results[name] = moran_bv

    sig = ("***" if moran_bv.p_sim < 0.001 else
           "**" if moran_bv.p_sim < 0.01 else
           "*" if moran_bv.p_sim < 0.05 else "不显著")
    print(f"    {name:<12}: I_BV={moran_bv.I:7.4f}, Z={moran_bv.z_sim:7.3f}, "
          f"p={moran_bv.p_sim:.4f} {sig}")

best_bv = max(moran_bv_results.values(), key=lambda m: abs(m.z_sim))
print(f"\n  → 双变量 Moran's I 结论:")
if best_bv.I > 0 and best_bv.p_sim < 0.05:
    print(f"     I_BV = {best_bv.I:.4f} > 0 且 p < 0.05 → 显著的空间正交叉相关！")
    print(f"     含义：民主党投票率高的州，其邻近州的LGBT人口比例也倾向于较高")
    print(f"          这反映了政治倾向与LGBT接纳度的空间溢出效应")
    print(f"          两种空间分布的集聚模式在一定程度上重合")
elif best_bv.p_sim >= 0.05:
    print(f"     双变量 Moran's I 不显著（p = {best_bv.p_sim:.4f}）")
    print(f"     两个变量的空间分布模式可能独立")
else:
    print(f"     I_BV = {best_bv.I:.4f} < 0 → 空间负交叉相关")

# %% ---------------------------------------------------------------
# 3.3 Moran 散点图（单变量 + 双变量）
# ---------------------------------------------------------------
# 3行×3列：Row0=DEM单变量, Row1=LGBT单变量, Row2=双变量
n_cols = len(weight_schemes)
fig, axes = plt.subplots(3, n_cols, figsize=(6 * n_cols, 16))
w_names = list(weight_schemes.keys())
w_list = list(weight_schemes.values())

# --- Row 0: 民主党投票率单变量 Moran 散点图 ---
vals = dem_values
y_std = (vals - vals.mean()) / vals.std()
for col_idx, (w_name, w) in enumerate(zip(w_names, w_list)):
    ax = axes[0, col_idx]
    lag = w.sparse.dot(y_std)
    ax.scatter(y_std, lag, s=30, alpha=0.5, c='#2166ac',
               edgecolors='white', linewidths=0.3)
    fit = np.polyfit(y_std, lag, 1)
    x_line = np.linspace(y_std.min(), y_std.max(), 100)
    ax.plot(x_line, np.polyval(fit, x_line), 'r-', linewidth=2)
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.8)
    ax.axvline(x=0, color='gray', linestyle='--', linewidth=0.8)
    moran = Moran(vals, w, permutations=999)
    ax.set_xlabel('民主党投票率（标准化）', fontsize=10)
    ax.set_ylabel('空间滞后值', fontsize=10)
    ax.set_title(f'民主党投票率 × {w_name}\nI={moran.I:.4f}, p={moran.p_sim:.4f}', fontsize=11)
    xl, yl = ax.get_xlim(), ax.get_ylim()
    ax.text(xl[1]*0.5, yl[1]*0.7, 'HH', fontsize=12, color='red', fontweight='bold', ha='center')
    ax.text(xl[0]*0.5, yl[1]*0.7, 'LH', fontsize=12, color='blue', fontweight='bold', ha='center')
    ax.text(xl[0]*0.5, yl[0]*0.7, 'LL', fontsize=12, color='darkblue', fontweight='bold', ha='center')
    ax.text(xl[1]*0.5, yl[0]*0.7, 'HL', fontsize=12, color='orange', fontweight='bold', ha='center')

# --- Row 1: LGBT比例单变量 Moran 散点图 ---
vals = lgbt_values
y_std = (vals - vals.mean()) / vals.std()
for col_idx, (w_name, w) in enumerate(zip(w_names, w_list)):
    ax = axes[1, col_idx]
    lag = w.sparse.dot(y_std)
    ax.scatter(y_std, lag, s=30, alpha=0.5, c='#d6604d',
               edgecolors='white', linewidths=0.3)
    fit = np.polyfit(y_std, lag, 1)
    x_line = np.linspace(y_std.min(), y_std.max(), 100)
    ax.plot(x_line, np.polyval(fit, x_line), 'r-', linewidth=2)
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.8)
    ax.axvline(x=0, color='gray', linestyle='--', linewidth=0.8)
    moran = Moran(vals, w, permutations=999)
    ax.set_xlabel('LGBT比例（标准化）', fontsize=10)
    ax.set_ylabel('空间滞后值', fontsize=10)
    ax.set_title(f'LGBT比例 × {w_name}\nI={moran.I:.4f}, p={moran.p_sim:.4f}', fontsize=11)
    xl, yl = ax.get_xlim(), ax.get_ylim()
    ax.text(xl[1]*0.5, yl[1]*0.7, 'HH', fontsize=12, color='red', fontweight='bold', ha='center')
    ax.text(xl[0]*0.5, yl[1]*0.7, 'LH', fontsize=12, color='blue', fontweight='bold', ha='center')
    ax.text(xl[0]*0.5, yl[0]*0.7, 'LL', fontsize=12, color='darkblue', fontweight='bold', ha='center')
    ax.text(xl[1]*0.5, yl[0]*0.7, 'HL', fontsize=12, color='orange', fontweight='bold', ha='center')

# --- Row 2: 双变量 Moran 散点图（民主党投票率 → LGBT比例空间滞后）---
dem_std = (dem_values - dem_values.mean()) / dem_values.std()
lgbt_std = (lgbt_values - lgbt_values.mean()) / lgbt_values.std()
for col_idx, (w_name, w) in enumerate(zip(w_names, w_list)):
    ax = axes[2, col_idx]
    lgbt_lag = w.sparse.dot(lgbt_std)
    ax.scatter(dem_std, lgbt_lag, s=30, alpha=0.5, c='#5e3c99',
               edgecolors='white', linewidths=0.3)
    fit = np.polyfit(dem_std, lgbt_lag, 1)
    x_line = np.linspace(dem_std.min(), dem_std.max(), 100)
    ax.plot(x_line, np.polyval(fit, x_line), 'r-', linewidth=2)
    ax.axhline(y=0, color='gray', linestyle='--', linewidth=0.8)
    ax.axvline(x=0, color='gray', linestyle='--', linewidth=0.8)
    moran_bv = Moran_BV(dem_values, lgbt_values, w, permutations=999)
    ax.set_xlabel('民主党投票率（标准化）', fontsize=10)
    ax.set_ylabel('LGBT比例 空间滞后', fontsize=10)
    ax.set_title(f'双变量：Dem → LGBT Lag × {w_name}\nI_BV={moran_bv.I:.4f}, p={moran_bv.p_sim:.4f}', fontsize=11)
    xl, yl = ax.get_xlim(), ax.get_ylim()
    ax.text(xl[1]*0.5, yl[1]*0.7, 'HH', fontsize=12, color='red', fontweight='bold', ha='center')
    ax.text(xl[0]*0.5, yl[1]*0.7, 'LH', fontsize=12, color='blue', fontweight='bold', ha='center')
    ax.text(xl[0]*0.5, yl[0]*0.7, 'LL', fontsize=12, color='darkblue', fontweight='bold', ha='center')
    ax.text(xl[1]*0.5, yl[0]*0.7, 'HL', fontsize=12, color='orange', fontweight='bold', ha='center')

plt.suptitle(f'Moran散点图全景：单变量 + 双变量空间交叉相关\n'
             f'行1: 民主党投票率 | 行2: LGBT比例 | 行3: 双变量（民主党→LGBT空间滞后）',
             fontsize=14, y=1.01)
plt.tight_layout()
plt.savefig('output_usa_04_moran_scatter.png', dpi=150, bbox_inches='tight')
plt.show()

# %% [markdown]
# ---
# # 步骤四：LISA 局部空间自相关分析

# %% ---------------------------------------------------------------
# 4.1 单变量 LISA（Local Moran's I）
# ---------------------------------------------------------------
print("\n" + "=" * 65)
print("步骤四：LISA 局部空间自相关分析")
print("=" * 65)

primary_w_name = 'Queen邻接' if queen_ok else list(weight_schemes.keys())[0]
primary_w = weight_schemes[primary_w_name]

lisa_colors = {0: '#d9d9d9', 1: '#d7191c', 2: '#abd9e9', 3: '#2c7bb6', 4: '#fdae61'}
lisa_labels = {0: '不显著', 1: 'HH（高-高）', 2: 'LH（低-高）', 3: 'LL（低-低）', 4: 'HL（高-低）'}

# 为两个变量分别计算LISA
lisa_results = {}
for var_name, var_label in [(VAR_DEM, VAR_DEM_LABEL), (VAR_LGBT, VAR_LGBT_LABEL)]:
    vals = gdf_valid[var_name].values.astype(float)
    lisa = Moran_Local(vals, primary_w, permutations=999)

    labels = lisa.q
    significant = lisa.p_sim <= 0.05

    lisa_class = np.zeros(len(vals), dtype=int)
    lisa_class[significant & (labels == 1)] = 1
    lisa_class[significant & (labels == 2)] = 2
    lisa_class[significant & (labels == 3)] = 3
    lisa_class[significant & (labels == 4)] = 4

    lisa_results[var_name] = (lisa, lisa_class)
    gdf_valid[f'lisa_{var_name}'] = lisa_class

    print(f"\n【{var_label} — LISA聚类结果（{primary_w_name}, p<0.05）】")
    for c, cname in [(1, 'HH（高-高）'), (3, 'LL（低-低）'), (4, 'HL（高-低）'), (2, 'LH（低-高）'), (0, '不显著')]:
        count = np.sum(lisa_class == c)
        pct = count / len(vals) * 100
        marker = f" ← 热点聚集区" if c == 1 else f" ← 冷点聚集区" if c == 3 else ""
        print(f"  {cname}: {count} 个州 ({pct:.1f}%){marker}")

    # 列出HH和LL的具体州
    for c, label in [(1, 'HH热点州'), (3, 'LL冷点州')]:
        if np.sum(lisa_class == c) > 0:
            names = gdf_valid.loc[gdf_valid.index[lisa_class == c], 'state_name'].tolist()
            print(f"    {label}: {', '.join(names)}")

# %% ---------------------------------------------------------------
# 4.2 单变量 LISA 聚类图
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(24, 9))

for idx, (var_name, var_label) in enumerate([(VAR_DEM, VAR_DEM_LABEL), (VAR_LGBT, VAR_LGBT_LABEL)]):
    ax = axes[idx]
    gdf_valid.plot(ax=ax, facecolor='none', edgecolor='#cccccc', linewidths=0.3)

    lisa_class = gdf_valid[f'lisa_{var_name}'].values
    for cls, color in list(lisa_colors.items())[::-1]:
        mask = lisa_class == cls
        if mask.any():
            gdf_valid[mask].plot(ax=ax, facecolor=color,
                                 edgecolors='gray', linewidths=0.3,
                                 alpha=0.85)

    for _, row in gdf_valid.iterrows():
        centroid = row.geometry.centroid
        ax.annotate(row['state'], (centroid.x, centroid.y),
                    fontsize=6, ha='center', va='center', color='#333333')

    ax.set_title(f'LISA聚类图：{var_label}\n（{primary_w_name}，仅着色p<0.05显著单元）', fontsize=13)
    ax.axis('off')

legend_elements = [Patch(facecolor=lisa_colors[c], edgecolor='gray', label=lisa_labels[c])
                   for c in [1, 3, 2, 4, 0]]
fig.legend(handles=legend_elements, loc='lower center', ncol=5, fontsize=11,
           title='LISA聚类类型', title_fontsize=12, bbox_to_anchor=(0.5, -0.02))

plt.tight_layout()
plt.savefig('output_usa_05_lisa_cluster.png', dpi=150, bbox_inches='tight')
plt.show()

print("\n【LISA聚类图解读】")
print("  HH（红色）：自身高 + 邻居高 → 民主党/ LGBT的'热点聚集区'")
print("    对于民主党投票率：可能是东北部、西海岸")
print("    对于LGBT比例：可能是西海岸、东北部走廊")
print("  LL（蓝色）：自身低 + 邻居低 → '冷点聚集区'")
print("    可能是南方Bible Belt和中部大平原地区")
print("  HL/LH（橙色/浅蓝）：空间异常值，反映局部不均衡")

# %% ---------------------------------------------------------------
# 4.3 双变量 LISA — 民主党投票率 vs LGBT比例空间滞后
# ---------------------------------------------------------------
print(f"\n【双变量LISA：民主党投票率 × LGBT比例空间滞后】")
print(f"  含义: 某州民主党投票率高/低，其邻近州的LGBT比例是否也高/低？")

lisa_bv = Moran_Local_BV(dem_values, lgbt_values, primary_w, permutations=999)

labels_bv = lisa_bv.q
sig_bv = lisa_bv.p_sim <= 0.05

lisa_bv_class = np.zeros(len(dem_values), dtype=int)
lisa_bv_class[sig_bv & (labels_bv == 1)] = 1
lisa_bv_class[sig_bv & (labels_bv == 2)] = 2
lisa_bv_class[sig_bv & (labels_bv == 3)] = 3
lisa_bv_class[sig_bv & (labels_bv == 4)] = 4

gdf_valid['lisa_bv'] = lisa_bv_class

for c, cname in [(1, 'HH'), (3, 'LL'), (4, 'HL'), (2, 'LH'), (0, '不显著')]:
    count = np.sum(lisa_bv_class == c)
    pct = count / len(dem_values) * 100
    desc = {1: '自身Dem↑，邻居LGBT↑ (空间协同热点)',
            3: '自身Dem↓，邻居LGBT↓ (空间协同冷点)',
            4: '自身Dem↑，邻居LGBT↓ (空间错配A)',
            2: '自身Dem↓，邻居LGBT↑ (空间错配B)'}.get(c, '')
    print(f"  {cname}: {count} 个州 ({pct:.1f}%) {desc}")

if np.sum(lisa_bv_class == 1) > 0:
    bv_hh = gdf_valid.loc[gdf_valid.index[lisa_bv_class == 1], 'state_name'].tolist()
    print(f"  双变量HH热点州（Dem↑邻居LGBT↑）: {', '.join(bv_hh)}")

# %% ---------------------------------------------------------------
# 4.4 LISA 综合对比图（三幅）
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(30, 9))

titles_plots = [
    (f'lisa_{VAR_DEM}', f'LISA: 民主党投票率\n（单变量）'),
    (f'lisa_{VAR_LGBT}', f'LISA: LGBT人口比例\n（单变量）'),
    ('lisa_bv', f'LISA: 民主党投票率 × LGBT空间滞后\n（双变量交叉相关）'),
]

for idx, (col, title) in enumerate(titles_plots):
    ax = axes[idx]
    gdf_valid.plot(ax=ax, facecolor='none', edgecolor='#cccccc', linewidths=0.3)

    lisa_c = gdf_valid[col].values
    for cls, color in lisa_colors.items():
        mask = lisa_c == cls
        if mask.any():
            gdf_valid[mask].plot(ax=ax, facecolor=color,
                                 edgecolors='gray', linewidths=0.3, alpha=0.85)

    for _, row in gdf_valid.iterrows():
        centroid = row.geometry.centroid
        ax.annotate(row['state'], (centroid.x, centroid.y),
                    fontsize=5.5, ha='center', va='center')

    ax.set_title(title, fontsize=13)
    ax.axis('off')

legend_elements = [Patch(facecolor=lisa_colors[c], edgecolor='gray', label=lisa_labels[c])
                   for c in [1, 3, 2, 4, 0]]
fig.legend(handles=legend_elements, loc='lower center', ncol=5, fontsize=11,
           title='LISA聚类类型', title_fontsize=12, bbox_to_anchor=(0.5, -0.02))

plt.suptitle(f'LISA分析全景对比（{primary_w_name}，p<0.05显著单元）\n'
             f'左: 民主党投票率 | 中: LGBT比例 | 右: 双变量交叉',
             fontsize=15, y=1.02)
plt.tight_layout()
plt.savefig('output_usa_06_lisa_comparison.png', dpi=150, bbox_inches='tight')
plt.show()

# %% [markdown]
# ---
# # 步骤五：Getis-Ord Gi* 热点分析

# %% ---------------------------------------------------------------
# 5.1 计算 Getis-Ord Gi*
# ---------------------------------------------------------------
print("\n" + "=" * 65)
print("步骤五：Getis-Ord Gi* 热点分析")
print("=" * 65)

gi_results = {}
for var_name, var_label in [(VAR_DEM, VAR_DEM_LABEL), (VAR_LGBT, VAR_LGBT_LABEL)]:
    vals = gdf_valid[var_name].values.astype(float)
    gi_star = G_Local(vals, primary_w, star=True, permutations=999)

    gi_results[var_name] = gi_star

    print(f"\n【{var_label} — Gi* 热点分析（{primary_w_name}）】")
    print(f"  Z值范围: [{gi_star.Zs.min():.3f}, {gi_star.Zs.max():.3f}]")

    for conf, label in [(0.01, '99%'), (0.05, '95%'), (0.10, '90%')]:
        hot = np.sum((gi_star.Zs > 0) & (gi_star.p_sim < conf))
        cold = np.sum((gi_star.Zs < 0) & (gi_star.p_sim < conf))
        print(f"  热点（{label}置信）: {hot} 个州 | 冷点（{label}置信）: {cold} 个州")

# %% ---------------------------------------------------------------
# 5.2 Gi* 热点图
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(24, 9))

for idx, (var_name, var_label) in enumerate([(VAR_DEM, VAR_DEM_LABEL), (VAR_LGBT, VAR_LGBT_LABEL)]):
    ax = axes[idx]
    gdf_valid.plot(ax=ax, facecolor='none', edgecolor='#cccccc', linewidths=0.3)

    gi_star = gi_results[var_name]
    gi_z = gi_star.Zs
    gi_p = gi_star.p_sim

    gi_class = np.zeros(len(gdf_valid), dtype=int)
    gi_class[(gi_z > 0) & (gi_p < 0.01)] = 3
    gi_class[(gi_z > 0) & (gi_p >= 0.01) & (gi_p < 0.05)] = 2
    gi_class[(gi_z > 0) & (gi_p >= 0.05) & (gi_p < 0.10)] = 1
    gi_class[(gi_z < 0) & (gi_p < 0.01)] = -3
    gi_class[(gi_z < 0) & (gi_p >= 0.01) & (gi_p < 0.05)] = -2
    gi_class[(gi_z < 0) & (gi_p >= 0.05) & (gi_p < 0.10)] = -1

    gi_colors = {-3: '#2166ac', -2: '#67a9cf', -1: '#d1e5f0', 0: '#f7f7f7',
                 1: '#fddbc7', 2: '#ef8a62', 3: '#b2182b'}
    gi_labels = {-3: '冷点(99%)', -2: '冷点(95%)', -1: '冷点(90%)',
                 0: '不显著', 1: '热点(90%)', 2: '热点(95%)', 3: '热点(99%)'}

    for cls in [3, 2, 1, -1, -2, -3, 0]:
        mask = gi_class == cls
        if mask.any():
            gdf_valid[mask].plot(ax=ax, facecolor=gi_colors[cls],
                                 edgecolors='gray', linewidths=0.3, alpha=0.85)

    for _, row in gdf_valid.iterrows():
        centroid = row.geometry.centroid
        ax.annotate(row['state'], (centroid.x, centroid.y),
                    fontsize=6, ha='center', va='center')

    ax.set_title(f'Gi* 热点图：{var_label}\n（{primary_w_name}）', fontsize=13)
    ax.axis('off')

legend_elements = [Patch(facecolor=gi_colors[c], edgecolor='gray', label=gi_labels[c])
                   for c in [3, 2, 1, -1, -2, -3, 0]]
fig.legend(handles=legend_elements, loc='lower center', ncol=7, fontsize=9)

plt.suptitle('Getis-Ord Gi* 热点分析：民主党投票率 vs LGBT人口比例', fontsize=14, y=1.02)
plt.tight_layout()
plt.savefig('output_usa_07_gistar_hotspot.png', dpi=150, bbox_inches='tight')
plt.show()

print("\n【Gi* 与 LISA 对比解读】")
print("  Gi* 优势：结果更平滑，适合向政策制定者呈现")
print("  Gi* 优势：包含自身值 — 检测的是'自身+邻居都高/低'的区域")
print("  LISA 优势：可识别空间异常值（HL/LH），揭示局部不均衡")
print("  → 两者互补：LISA找异常，Gi*找中心")

# %% [markdown]
# ---
# # 步骤六：稳健性检验

# %% ---------------------------------------------------------------
# 6.1 多权重方案 Global Moran's I 对比
# ---------------------------------------------------------------
print("\n" + "=" * 65)
print("步骤六：稳健性检验（多权重方案对比）")
print("=" * 65)

print(f"\n{'─' * 70}")
print("  【单变量 Moran's I 稳健性】")
print(f"  {'权重方案':<12} {'Dem I':>8} {'Dem p':>10} {'LGBT I':>8} {'LGBT p':>10}")
print(f"  {'─' * 50}")

for name in weight_schemes:
    md = moran_dem_results[name]
    ml = moran_lgbt_results[name]
    print(f"  {name:<12} {md.I:>8.4f} {md.p_sim:>10.4f} {ml.I:>8.4f} {ml.p_sim:>10.4f}")

print(f"\n  {'─' * 70}")
print("  【双变量 Moran's I 稳健性】")
print(f"  {'权重方案':<12} {'I_BV':>8} {'p值':>10} {'方向':>8}")
print(f"  {'─' * 40}")

for name, mbv in moran_bv_results.items():
    dir_bv = "正交叉" if mbv.I > 0 else "负交叉"
    print(f"  {name:<12} {mbv.I:>8.4f} {mbv.p_sim:>10.4f} {dir_bv:>8}")

print(f"\n  【稳健性判断】")
all_pos = all(m.I > 0 for m in moran_bv_results.values())
all_sig = all(m.p_sim < 0.05 for m in moran_bv_results.values())
print(f"  ✓ 方向一致：所有权重下双变量Moran's I均为{'正' if all_pos else '不一致'}")
print(f"  {'✓' if all_sig else '⚠'} 显著性一致：所有方案下{'p<0.001，高度显著' if all_sig else '显著性不一致'}")
if all_pos and all_sig:
    print(f"  → 结论高度稳健！民主党选票与LGBT分布的空间交叉相关不受权重选择影响")
else:
    print(f"  ⚠ 部分方案结果不一致，需进一步分析")

# %% ---------------------------------------------------------------
# 6.2 稳健性可视化
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(20, 6))

scheme_names = list(weight_schemes.keys())

# (1) 单变量 Moran's I 对比
x = np.arange(len(scheme_names))
width = 0.3
dem_ivals = [moran_dem_results[n].I for n in scheme_names]
lgbt_ivals = [moran_lgbt_results[n].I for n in scheme_names]

axes[0].bar(x - width/2, dem_ivals, width, color='#2166ac', alpha=0.8, label='民主党投票率')
axes[0].bar(x + width/2, lgbt_ivals, width, color='#d6604d', alpha=0.8, label='LGBT比例')
axes[0].axhline(y=0, color='black', linewidth=0.8)
axes[0].set_xticks(x)
axes[0].set_xticklabels(scheme_names, fontsize=10)
axes[0].set_ylabel("Moran's I", fontsize=11)
axes[0].set_title('单变量 Moran\'s I 对比', fontsize=13)
axes[0].legend(fontsize=10)

for i, (dv, lv) in enumerate(zip(dem_ivals, lgbt_ivals)):
    axes[0].text(i - width/2, dv + 0.01, f'{dv:.3f}', ha='center', fontsize=8, fontweight='bold')
    axes[0].text(i + width/2, lv + 0.01, f'{lv:.3f}', ha='center', fontsize=8, fontweight='bold')

# (2) 双变量 Moran's I 对比
bv_ivals = [moran_bv_results[n].I for n in scheme_names]
bv_colors = ['#d7191c' if v > 0 else '#2c7bb6' for v in bv_ivals]
axes[1].bar(scheme_names, bv_ivals, color=bv_colors, edgecolor='white', alpha=0.8)
axes[1].axhline(y=0, color='black', linewidth=0.8)
for i, v in enumerate(bv_ivals):
    axes[1].text(i, v + 0.01, f'{v:.3f}', ha='center', fontsize=9, fontweight='bold')
axes[1].set_ylabel("双变量 Moran's I", fontsize=11)
axes[1].set_title('双变量 Moran\'s I 对比\n（Dem → LGBT空间滞后）', fontsize=13)

# (3) p值对比
bv_pvals = [moran_bv_results[n].p_sim for n in scheme_names]
axes[2].bar(scheme_names, bv_pvals, color='steelblue', edgecolor='white', alpha=0.8)
axes[2].axhline(y=0.05, color='red', linestyle='--', linewidth=2, label='α=0.05')
axes[2].axhline(y=0.01, color='orange', linestyle='--', linewidth=1.5, label='α=0.01')
axes[2].set_ylabel('p值', fontsize=11)
axes[2].set_title('双变量 Moran\'s I: p值对比', fontsize=13)
axes[2].legend(fontsize=9)
for i, v in enumerate(bv_pvals):
    axes[2].text(i, max(v, 0.0001) + 0.001, f'{v:.4f}', ha='center', fontsize=9)

plt.suptitle('稳健性检验：不同权重方案下空间自相关指标对比', fontsize=14, y=1.02)
plt.tight_layout()
plt.savefig('output_usa_08_robustness.png', dpi=150, bbox_inches='tight')
plt.show()

# %% ---------------------------------------------------------------
# 6.3 LISA稳健性对比（多权重）
# ---------------------------------------------------------------
n_schemes = len(weight_schemes)
fig, axes = plt.subplots(2, n_schemes, figsize=(8 * n_schemes, 14))

for row, (var_name, var_label) in enumerate([(VAR_DEM, VAR_DEM_LABEL), (VAR_LGBT, VAR_LGBT_LABEL)]):
    vals = gdf_valid[var_name].values.astype(float)
    for col, (w_name, w) in enumerate(weight_schemes.items()):
        ax = axes[row, col] if n_schemes > 1 else axes[row]
        gdf_valid.plot(ax=ax, facecolor='none', edgecolor='#cccccc', linewidths=0.3)

        lisa_w = Moran_Local(vals, w, permutations=999)
        labels_w = lisa_w.q
        sig_w = lisa_w.p_sim <= 0.05
        class_w = np.zeros(len(vals), dtype=int)
        class_w[sig_w & (labels_w == 1)] = 1
        class_w[sig_w & (labels_w == 2)] = 2
        class_w[sig_w & (labels_w == 3)] = 3
        class_w[sig_w & (labels_w == 4)] = 4

        for cls, color in lisa_colors.items():
            mask = class_w == cls
            if mask.any():
                gdf_valid[mask].plot(ax=ax, facecolor=color,
                                     edgecolors='gray', linewidths=0.2, alpha=0.8)

        n_sig = np.sum(sig_w)
        ax.set_title(f'{var_label} × {w_name}\n显著: {n_sig}/{len(vals)}', fontsize=11)
        ax.axis('off')

legend_elements = [Patch(facecolor=lisa_colors[c], edgecolor='gray', label=lisa_labels[c])
                   for c in [1, 3, 2, 4, 0]]
fig.legend(handles=legend_elements, loc='lower center', ncol=5, fontsize=11,
           title='LISA聚类类型', title_fontsize=12, bbox_to_anchor=(0.5, -0.02))

fig.suptitle('LISA稳健性对比：不同权重方案下的局部聚类模式', fontsize=14, y=1.02)
plt.tight_layout()
plt.savefig('output_usa_09_lisa_robustness.png', dpi=150, bbox_inches='tight')
plt.show()

# %% [markdown]
# ---
# # 分析总结

# %% ---------------------------------------------------------------
print("\n" + "=" * 65)
print("分析总结 —— 核心发现")
print("=" * 65)

primary_dem = moran_dem_results[primary_w_name]
primary_lgbt = moran_lgbt_results[primary_w_name]
primary_bv = moran_bv_results[primary_w_name]

print(f"""
发现一：美国各州民主党投票率存在高度显著的正空间自相关
  Moran's I = {primary_dem.I:.4f}  (p = {primary_dem.p_sim:.6f})
  含义："蓝州"倾向与"蓝州"为邻，"红州"倾向与"红州"为邻
  空间模式：东北部-西海岸形成"蓝色走廊"，南方-内陆形成"红色腹地"

发现二：美国各州LGBT人口比例同样存在显著的正空间自相关
  Moran's I = {primary_lgbt.I:.4f}  (p = {primary_lgbt.p_sim:.6f})
  含义：LGBT友好度/可见度高的州在空间上聚集
  空间模式：海岸地区LGBT比例高，内陆/南方地区比例低

发现三（核心发现）：民主党投票率与LGBT分布存在显著的双变量空间交叉相关！
  双变量 Moran's I = {primary_bv.I:.4f}  (p = {primary_bv.p_sim:.6f})
  含义：一个州民主党投票率高 → 其邻近州的LGBT人口比例也倾向于高
  解释：政治气候与LGBT社会接纳度存在空间溢出效应
  可能机制：
    1. 政策扩散：邻近蓝州的州可能受LGBT友好政策影响
    2. 文化溢出：开放的政治文化跨州界传播
    3. 人口迁移：LGBT群体向包容性地区及周边迁移
    4. 共同驱动：城市化、教育水平等因素同时影响投票和LGBT分布

发现四：三种权重方案（Queen/KNN4/KNN8）下结论高度一致
  双变量Moran's I在所有方案下均为正且显著 → 结论稳健

发现五（区域对比）：
  HH热点（Dem↑邻居LGBT↑）：西海岸、东北部
  LL冷点（Dem↓邻居LGBT↓）：南方Bible Belt、中部大平原
  → 两个变量的空间集聚模式高度重叠
""")

print("-" * 65)
print("方法讨论：空间自相关是【因】还是【果】？")
print("-" * 65)
print("""
  检测到空间自相关只是开始。可能的空间过程：

  1. 空间溢出/政策扩散 → 自相关是因果
     例：加州/纽约的LGBT友好政策影响周边州

  2. 社会人口分选 → 共同驱动因素
     例：城市化水平同时影响投票倾向和LGBT分布

  3. 文化地理 → 深层结构性因素
     例：美国南方文化传统 vs 东北部自由主义传统

  4. 制度模仿 → 邻近效应
     例：州政府在政策上模仿邻近"标杆"州

  → 双变量空间自相关揭示了格局，但要确立因果关系，
     需要进一步的SEM/SAR空间回归模型！
""")

print("=" * 65)
print(f"分析完成！共生成 9 张结果图（output_usa_01 ~ output_usa_09.png）")
print(f"核心结论：美国民主党投票率与LGBT人口分布存在")
print(f"         显著的空间双变量正交叉相关（I_BV = {primary_bv.I:.4f}, p < {primary_bv.p_sim:.4f}）")
print("=" * 65)
